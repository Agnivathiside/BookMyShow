package com.bookMyShowClone.movieService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
